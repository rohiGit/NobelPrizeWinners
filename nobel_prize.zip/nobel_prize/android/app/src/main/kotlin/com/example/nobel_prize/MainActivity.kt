package com.example.nobel_prize

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
